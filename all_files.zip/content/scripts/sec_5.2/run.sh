# Add /content to the PYTHONPATH
export PYTHONPATH=$PYTHONPATH:/content

python scripts/sec_5.2/run.py toy-paper-run