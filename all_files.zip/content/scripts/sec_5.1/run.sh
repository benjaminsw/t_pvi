# Add /content to the PYTHONPATH
export PYTHONPATH=$PYTHONPATH:/content


python scripts/sec_5.1/runner.py linear_skip
python scripts/sec_5.1/runner.py skip
python scripts/sec_5.1/runner.py push
python scripts/sec_5.1/runner.py constant
