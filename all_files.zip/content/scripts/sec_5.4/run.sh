# Add /content to the PYTHONPATH
export PYTHONPATH=$PYTHONPATH:/content


python scripts/sec_5.4/runner.py concrete pvi
python scripts/sec_5.4/runner.py concrete uvi
python scripts/sec_5.4/runner.py concrete svi
python scripts/sec_5.4/runner.py concrete sm

python scripts/sec_5.4/runner.py yacht pvi
python scripts/sec_5.4/runner.py yacht uvi
python scripts/sec_5.4/runner.py yacht svi
python scripts/sec_5.4/runner.py yacht sm

python scripts/sec_5.4/runner.py protein pvi
python scripts/sec_5.4/runner.py protein svi
python scripts/sec_5.4/runner.py protein uvi
python scripts/sec_5.4/runner.py protein sm
