# Add /content to the PYTHONPATH
export PYTHONPATH=$PYTHONPATH:/content

python scripts/sec_5.3/runner.py waveform pvi
python scripts/sec_5.3/runner.py waveform svi
python scripts/sec_5.3/runner.py waveform uvi
python scripts/sec_5.3/runner.py waveform sm